/*
   The MIT License (MIT)

   Copyright (c) 2016 British Broadcasting Corporation.
   This software is provided by Lancaster University by arrangement with the BBC.

   Permission is hereby granted, free of charge, to any person obtaining a
   copy of this software and associated documentation files (the "Software"),
   to deal in the Software without restriction, including without limitation
   the rights to use, copy, modify, merge, publish, distribute, sublicense,
   and/or sell copies of the Software, and to permit persons to whom the
   Software is furnished to do so, subject to the following conditions:

   The above copyright notice and this permission notice shall be included in
   all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
   DEALINGS IN THE SOFTWARE.
   */

#include "MicroBit.h"
#include "MicroBitStorage.h"
#include "ssd1306.h"
// for TSL2561 : Lumière visible et infra-rouge
#include "tsl256x.h"
// for BME280 : Température, Humidité, Pression
#include "bme280.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
// #include <tinycrypt/ecc.h>
// #include <tinycrypt/sha256.h>
// #include <tinycrypt/ecc_dh.h>
// #include <tinycrypt/constants.h>

#define LUX 1
#define TEMP 2
#define HUMIDITY 3
#define PRESSURE 4
#define IR 5
#define MAX_DATA_SIZE 5
#define DEVICE_ID 80743
#define SERVER_ID_STORAGE_KEY "server_id"
#define SERVER_PUBLIC_KEY_STORAGE_KEY "server_public_key"
#define ME_PRIVATE_KEY_STORAGE_KEY "me_private_key"

MicroBit uBit;
MicroBitStorage storage;
MicroBitI2C i2c(I2C_SDA0, I2C_SCL0);
MicroBitPin P0(MICROBIT_ID_IO_P0, MICROBIT_PIN_P0, PIN_CAPABILITY_DIGITAL_OUT);

int dataTypes[MAX_DATA_SIZE] = {LUX, TEMP, HUMIDITY, PRESSURE, IR};
int dataTypesSize = 5;
int counter = 0;

int server_id = -1;

uint8_t privateKey[32];
uint8_t publicKey[64];

// Define the curve to use
// const struct uECC_Curve_t *curve = uECC_secp256r1();

// Function prototypes
// void generate_keys(uint8_t *publicKey, uint8_t *privateKey) {
//     int result = uECC_make_key(publicKey, privateKey, uECC_secp256r1());
//     if (result != TC_CRYPTO_SUCCESS) {
//         // Handle error (e.g., return an error code or use logging)
//     }
// }

// void encrypt_message(const uint8_t *publicKey, uint8_t *message, uint8_t *ciphertext, uint8_t *privateKey) {
//     uint8_t shared_secret[32]; // Shared secret buffer
//     int result = uECC_shared_secret(publicKey, privateKey, shared_secret, uECC_secp256r1());
//     if (result != TC_CRYPTO_SUCCESS) {
//         // Handle error
//     }

//     // Use the shared secret as a key for AES encryption (assuming AES-256)
//     aes_encrypt(shared_secret, message, ciphertext);  // Implement AES encryption function
// }

// void decrypt_message(const uint8_t *privateKey, const uint8_t *publicKey, uint8_t *ciphertext, uint8_t *decryptedMessage) {
//     uint8_t shared_secret[32]; // Shared secret buffer
//     int result = uECC_shared_secret(publicKey, privateKey, shared_secret, uECC_secp256r1());
//     if (result != TC_CRYPTO_SUCCESS) {
//         // Handle error
//     }

//     // Use the shared secret as a key for AES decryption
//     aes_decrypt(shared_secret, ciphertext, decryptedMessage);  // Implement AES decryption function
// }

/**
 * @brief Resets all elements in the dataTypes array to zero.
 *
 * This function iterates through the dataTypes array and sets each element to zero.
 * It assumes that the array has a size defined by the constant MAX_DATA_SIZE.
 *
 * @return int Always returns 0.
 */
int clean_datatype()
{
    for (int i = 0; i < MAX_DATA_SIZE; i++)
    {
        dataTypes[i] = 0;
    }
    return 0;
}

int get_server_id()
{
    KeyValuePair *server_id_kv = storage.get(SERVER_ID_STORAGE_KEY);
    if (server_id_kv == NULL)
    {
        return -1;
    }
    return *(int *)server_id_kv->value;
}

int set_server_id(int server_id)
{
    return storage.put(SERVER_ID_STORAGE_KEY, (uint8_t *)&server_id, sizeof(server_id));
}

// uint8_t *get_server_public_key()
// {
//     KeyValuePair *server_public_key_kv = storage.get(SERVER_PUBLIC_KEY_STORAGE_KEY);
//     if (server_public_key_kv == NULL)
//     {
//         return NULL;
//     }

//     uint8_t *server_public_key = (uint8_t *)malloc(sizeof(server_public_key_kv->value));
//     memcpy(server_public_key, server_public_key_kv->value, sizeof(server_public_key_kv->value));
//     return server_public_key;
// }

// int set_server_public_key(uint8_t *server_public_key, int length)
// {
//     return storage.put(SERVER_PUBLIC_KEY_STORAGE_KEY, server_public_key, length);
// }

// uint8_t *get_me_private_key()
// {
//     KeyValuePair *server_private_key_kv = storage.get(ME_PRIVATE_KEY_STORAGE_KEY);
//     if (server_private_key_kv == NULL)
//     {
//         return NULL;
//     }

//     uint8_t *server_private_key = (uint8_t *)malloc(sizeof(server_private_key_kv->value));
//     memcpy(server_private_key, server_private_key_kv->value, sizeof(server_private_key_kv->value));
//     return server_private_key;
// }

// int set_me_private_key(uint8_t *server_private_key, int length)
// {
//     return storage.put(ME_PRIVATE_KEY_STORAGE_KEY, server_private_key, length);
// }

/**
 * @brief Sends a message using the micro:bit radio datagram.
 *
 * This function attempts to send a message via the micro:bit's radio datagram.
 * If the message is successfully sent, the micro:bit's display will scroll "SENT".
 * If the message fails to send, the display will scroll "FAILED".
 *
 * @param message A pointer to the character array containing the message to be sent.
 * @return int Returns 1 if the message was successfully sent, otherwise returns 0.
 */
int send_message(char *message)
{
    int resp = uBit.radio.datagram.send(ManagedString(server_id) + " " + message);

    if (resp == MICROBIT_OK)
    {
        uBit.display.scroll("ST");
        return 1;
    }
    else
    {
        uBit.display.scroll("FD");
        return 0;
    }
}

/**
 * @brief Reads the lux and infrared (IR) values from the TSL256x sensor.
 *
 * This function initializes the TSL256x sensor, reads the combined light value,
 * the infrared light value, and the lux value, and stores them in the provided
 * pointers.
 *
 * @param lux Pointer to an integer where the lux value will be stored.
 * @param ir Pointer to an integer where the infrared light value will be stored.
 * @return int Status code indicating the success or failure of the sensor read operation.
 */
int get_lux_ir_sensor(int *lux, int *ir)
{
    // Initialize the TSL256x sensor (adjust the constructor parameters if needed)
    tsl256x tsl(&uBit, &i2c);

    // Variables to hold the sensor values
    uint16_t comb = 0;    // Combined light (visible + IR)
    uint16_t ir_val = 0;  // Infrared light
    uint32_t lux_val = 0; // Calculated lux value

    // Read sensor values
    int resp = tsl.sensor_read(&comb, &ir_val, &lux_val);

    // Check if the read operation was successful
    if (resp != 0)
    {
        return resp; // Return error code if the sensor read failed
    }

    // Store the values in the provided pointers
    *lux = (int)lux_val;
    *ir = (int)ir_val;

    return 0; // Success
}

/**
 * @brief Reads the temperature, pressure, and humidity values from the BME280 sensor.
 *
 * This function initializes the BME280 sensor, reads the raw temperature, pressure,
 * and humidity values, compensates them using the sensor's calibration, and stores
 * the final results in the provided pointers.
 *
 * @param temp Pointer to an integer where the compensated temperature value (in °C) will be stored.
 * @param pressure Pointer to an integer where the compensated pressure value (in hPa) will be stored.
 * @param humidity Pointer to an integer where the compensated humidity value (in %) will be stored.
 * @return int Status code indicating the success or failure of the sensor read operation.
 */
int get_temp_pressure_humidity_sensor(int *temp, int *pressure, int *humidity)
{
    // Initialize the BME280 sensor (adjust the constructor parameters if needed)
    bme280 bme(&uBit, &i2c);

    // Variables to hold the raw sensor values
    uint32_t raw_pressure = 0;
    int32_t raw_temp = 0;
    uint16_t raw_humidity = 0;

    // Read raw sensor values
    int resp = bme.sensor_read(&raw_pressure, &raw_temp, &raw_humidity);

    // Check if the read operation was successful
    if (resp != 0)
    {
        return resp; // Return error code if the sensor read failed
    }

    // Compensate the raw sensor values
    int compensated_temp = bme.compensate_temperature(raw_temp);
    int compensated_pressure = bme.compensate_pressure(raw_pressure) / 100; // Convert pressure to hPa
    int compensated_humidity = bme.compensate_humidity(raw_humidity);

    // Store the compensated values in the provided pointers
    *temp = compensated_temp;
    *pressure = compensated_pressure;
    *humidity = compensated_humidity;

    return 0; // Success
}

/**
 * @brief Retrieves sensor data based on the specified data types.
 *
 * This function returns the sensor data for the given data types. The data types
 * can be a combination of the following:
 * - LUX: Light sensor data
 * - TEMP: Temperature sensor data
 * - PRESSURE: Pressure sensor data
 * - HUMIDITY: Humidity sensor data
 *
 * The function returns a string containing the requested data in the order specified.
 *
 * @param dataTypes Array of data types to retrieve (LUX, TEMP, PRESSURE, HUMIDITY).
 * @param numDataTypes Number of data types in the dataTypes array.
 * @param forServer Boolean indicating if the data is for the server or not.
 * @return A string containing the sensor data in the specified order.
 */
char *get_sensor_data(int *dataTypes, int numDataTypes, bool forServer = false)
{
    // Buffers to store sensor data as strings
    static char result[256]; // Buffer for the final result
    char buffer[32];         // Temporary buffer for each sensor value
    result[0] = '\0';        // Ensure the result string is empty at the start

    // Variables to hold sensor readings
    int lux = 0, temp = 0, pressure = 0, humidity = 0;

    // Loop through each requested data type
    for (int i = 0; i < numDataTypes; i++)
    {
        switch (dataTypes[i])
        {
        case LUX:
            // Get lux sensor data
            get_lux_ir_sensor(&lux, NULL); // Assume IR is not needed here
            if (forServer)
            {
                snprintf(buffer, sizeof(buffer), "%d:%d ", LUX, lux);                
            }
            else
            {
                snprintf(buffer, sizeof(buffer), "LUX:%d ", lux);
            }
            strcat(result, buffer); // Append lux data to the result
            break;

        case TEMP:
            // Get temperature data
            get_temp_pressure_humidity_sensor(&temp, NULL, NULL); // Only temp
            // ManagedString display = "Temp:" + ManagedString(temp/100) + "." + (temp > 0 ? ManagedString(temp%100): ManagedString((-temp)%100))+" C";

            if (forServer)
            {
                snprintf(buffer, sizeof(buffer), "%d:%d ", TEMP, temp / 100 + (temp > 0 ? 0 : 1));
            }
            else
            {
                snprintf(buffer, sizeof(buffer), "TEMP:%d ", temp / 100 + (temp > 0 ? 0 : 1));
            }

            strcat(result, buffer); // Append temp data to the result
            break;

        case PRESSURE:
            // Get pressure data
            get_temp_pressure_humidity_sensor(NULL, &pressure, NULL); // Only pressure

            if (forServer)
            {
                snprintf(buffer, sizeof(buffer), "%d:%d ", PRESSURE, pressure);
            }
            else
            {
                snprintf(buffer, sizeof(buffer), "PRESSURE:%d hPa ", pressure);
            }

            strcat(result, buffer); // Append pressure data to the result
            break;

        case HUMIDITY:
            // Get humidity data
            get_temp_pressure_humidity_sensor(NULL, NULL, &humidity); // Only humidity

            if (forServer)
            {
                snprintf(buffer, sizeof(buffer), "%d:%d ", HUMIDITY, humidity);
            }
            else
            {
                snprintf(buffer, sizeof(buffer), "HUMIDITY:%d%% ", humidity);
            }

            strcat(result, buffer); // Append humidity data to the result
            break;

        case IR:
            // Get IR sensor data
            get_lux_ir_sensor(NULL, &lux); // Assume lux is not needed here

            if (forServer)
            {
                snprintf(buffer, sizeof(buffer), "%d:%d ", IR, lux);
            }
            else
            {
                snprintf(buffer, sizeof(buffer), "IR:%d ", lux);
            }

            strcat(result, buffer); // Append IR data to the result
            break;

            // default:
            //  If an unknown data type is requested, append an error message
            //  snprintf(buffer, sizeof(buffer), "UNKNOWN TYPE ");
            //  strcat(result, buffer);
            //  break;
        }
    }

    return result;
}

/**
 * @brief Handles the "hello" message by extracting the server ID and public key.
 *
 * The message is expected to be in the format: "id-28 <serverID> <publicKey>"
 *
 * @param s The input message as a ManagedString.
 * @return int Returns 0 on success, or an error code if setting the server ID or public key fails.
 */
int handle_hello()
{
    int resp = uBit.radio.datagram.send("id-28 " + ManagedString(server_id));

    return resp;
}

/**
 * @brief Handles the incoming message by parsing it and processing sensor data.
 *
 * This function takes a ManagedString message, cleans the data type array,
 * parses the message to extract sensor data types, retrieves the sensor data,
 * and sends the processed data.
 *
 * @param s The incoming message as a ManagedString. The message format is expected
 *          to have a 5-digit ID followed by a space and then the sensor data types.
 *          For example, "12345 423" where "423" indicates PRESSURE, TEMP, HUMIDITY.
 *
 * @return int Status code indicating the success or failure of the message handling.
 */
int handle_message(ManagedString s)
{
    clean_datatype();
    // parse the received message like: 423 means PRESSURE, TEMP, HUMIDITY
    // the message comes after the 5 digit of the id and a space
    dataTypesSize = 0;
    ManagedString sub = s.substring(5, s.length() - 5);
    for (int i = 0; i < sub.length(); i++)
    {
        // recize the array
        dataTypes[dataTypesSize] = sub.charAt(i) - '0';
        dataTypesSize++;
    }

    char *sensorData = get_sensor_data(dataTypes, dataTypesSize);
    send_message(sensorData);

    return 0;
}

/**
 * @brief Handles the reception of messages via the radio datagram.
 *
 * This function is triggered by a MicroBitEvent and processes the received
 * message. Depending on the content of the message, it displays a corresponding
 * character on the MicroBit's display.
 *
 * @param event The MicroBitEvent that triggers this function.
 *
 * - If the received message is "1", it displays "A".
 * - If the received message is "2", it displays "B".
 */
void receive_message(MicroBitEvent)
{
    ManagedString s = uBit.radio.datagram.recv();

    uBit.display.scroll("R");

    // if the received message begin with 'id-28' then it's the hello message
    if (s.charAt(0) == 'i' && s.charAt(1) == 'd' && s.charAt(2) == '-' && s.charAt(3) == '2' && s.charAt(4) == '8')
    {
        uBit.display.scroll("H");
        handle_hello();
    }
    // data has to begin with the 5 digit of the id (id int var) of the device and then space and the data types like "123456 423"
    else 
    {
        handle_message(s);
    }
}

int main()
{
    // Initialise the micro:bit runtime.
    uBit.init();

    ssd1306 screen(&uBit, &i2c, &P0);

    int temp_server_id = get_server_id();
    // uint8_t *temp_server_public_key = get_server_public_key();
    // uint8_t *temp_server_private_key = get_me_private_key();

    if (temp_server_id != -1)
    {
        server_id = temp_server_id;
    } else {
        // generate a random server id between 10 and 99
        server_id = rand() % 90 + 10;
        set_server_id(server_id);
    }

    // if (temp_server_public_key != NULL)
    // {
    //     memcpy(publicKey, temp_server_public_key, 64);
    // }

    // if (temp_server_private_key != NULL)
    // {
    //     memcpy(privateKey, temp_server_private_key, 32);
    // }

    // scroll the server id
    char id_str[12];
    snprintf(id_str, sizeof(id_str), "%d", server_id);
    uBit.display.scroll(id_str);

    // Enable the radio
    uBit.messageBus.listen(MICROBIT_ID_RADIO, MICROBIT_RADIO_EVT_DATAGRAM, receive_message);
    uBit.radio.enable();
    uBit.radio.setGroup(28);

    while (true)
    {
        char *sensorData = get_sensor_data(dataTypes, dataTypesSize);

        // if there is no sensor data, display an error message
        if (strlen(sensorData) == 0)
        {
            strcpy(sensorData, "");
        }

        // send the data every 10 seconds to the server
        if (counter % 10 == 0 || uBit.buttonA.isPressed())
        {
            char *serverSensorData = get_sensor_data(dataTypes, dataTypesSize, true);
            send_message(serverSensorData);
        }

        screen.display_line(0, 0, sensorData);

        screen.update_screen();
        uBit.sleep(1000);
        counter++;
    }
}