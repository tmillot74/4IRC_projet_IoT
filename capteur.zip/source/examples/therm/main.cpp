#include "MicroBit.h"

MicroBit uBit;
MicroBitThermometer therm;

int main()
{
    // Initialise the micro:bit runtime.
    uBit.init();

    // Infinite loop to constantly show temperature
    while (true)
    {
        // Get the current temperature in Celsius
        int celcius = therm.getTemperature();

        // Display the temperature on the micro:bit's LED display
        uBit.display.scroll(celcius);

        // Small delay to avoid overwhelming the display
        uBit.sleep(2000); // sleep for 2 seconds
    }

    // This won't be reached but it's required to keep the program running
    release_fiber();
}
