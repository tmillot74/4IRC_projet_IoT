// In source/main.cpp
#include "MicroBit.h"
#include "mbed.h"

MicroBit uBit;

int main()
{
    uBit.init();
    

    while (true)
    {
        uBit.io.P8.setDigitalValue(1);
        uBit.sleep(500);
        uBit.io.P8.setDigitalValue(0);
        uBit.io.P12.setDigitalValue(1);
        uBit.sleep(500);
        uBit.io.P12.setDigitalValue(0);
        uBit.io.P16.setDigitalValue(1);
        uBit.sleep(500);
        uBit.io.P16.setDigitalValue(0);
    }
    release_fiber();
}
