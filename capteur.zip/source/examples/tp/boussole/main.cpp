// In source/main.cpp
#include "MicroBit.h"

MicroBit uBit;

int main()
{
    uBit.init();
    uBit.compass.calibrate();

    while (true)
    {
        int heading = uBit.compass.heading();
        if (heading >= 45 && heading < 135) {
            uBit.display.print("E");
        }
        else if (heading >= 135 && heading < 225) {
            uBit.display.print("S");
        }
        else if (heading >= 225 && heading < 315) {
            uBit.display.print("O");
        }
        else {
            uBit.display.print("N");
        }
        uBit.sleep(500);
    }
    release_fiber();
}
