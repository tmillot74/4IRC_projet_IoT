#include "MicroBit.h"

#define LUX 1
#define TEMP 2
#define HUMIDITY 3
#define PRESSURE 4
#define IR 5

int dataTypes[5] = { LUX, TEMP, HUMIDITY, PRESSURE, IR };
int dataTypesSize = 5;
int idOfTheDevice = 0;

MicroBit uBit;
MicroBitI2C i2c = MicroBitI2C(I2C_SDA0, I2C_SCL0);


/**
 * @brief Sends a message using the micro:bit radio datagram.
 *
 * This function attempts to send a message via the micro:bit's radio datagram.
 * If the message is successfully sent, the micro:bit's display will scroll "SENT".
 * If the message fails to send, the display will scroll "FAILED".
 *
 * @param message A pointer to the character array containing the message to be sent.
 * @return int Returns 1 if the message was successfully sent, otherwise returns 0.
 */
int send_message(char *message)
{
    int resp = uBit.radio.datagram.send(message);
    if (resp == MICROBIT_OK)
    {
        uBit.display.scroll("S");
        return 1;
    }
    else
    {
        uBit.display.scroll("F");
        return 0;
    }
}

/*
 * This function attempts to receive a message via the micro:bit's radio datagram.
 * If a message is successfully received, the message will be printed to the serial port.
 */
void sendOrder(ManagedString order) {
    ManagedString messageToSend = ManagedString(idOfTheDevice) + " " + order;
    uBit.radio.datagram.send(messageToSend);
}

/*
 * This function sends a message to the device to get the id of the device
 */
void sendIdRequest() {
    uBit.radio.datagram.send("id-28");
}

/**
 * @brief Handles the reception of messages via the radio datagram.
 *
 * This function is triggered by a MicroBitEvent and processes the received
 * message. Depending on the content of the message, it displays a corresponding
 * character on the MicroBit's display.
 *
 * @param event The MicroBitEvent that triggers this function.
 *
 * - If the received message is "1", it displays "A".
 * - If the received message is "2", it displays "B".
 */
void receive_message(MicroBitEvent)
{
    ManagedString s = uBit.radio.datagram.recv();
    // uBit.display.scroll(s);

    // if the beginning of the message is "id-28" then we are receiving the id of the device after the "-28" we have a space at the end 
    if (s.substring(0, 5) == "id-28") {
        idOfTheDevice = atoi(s.substring(6, s.length()).toCharArray());
        uBit.serial.send("id of the device: " + ManagedString(idOfTheDevice));
    }

    // if the beggining of the message is with the id of the device then we are receiving the data to send to the serial 
    if (s.substring(0, 2) == ManagedString(idOfTheDevice)) 
        uBit.serial.send(s.substring(3, s.length()));
}


int main() {
    uBit.init(); 

    uBit.radio.enable();
    uBit.radio.setGroup(28); 
    uBit.serial.setRxBufferSize(128);

    // Request the id of the device
    sendIdRequest();
    uBit.messageBus.listen(MICROBIT_ID_RADIO, MICROBIT_RADIO_EVT_DATAGRAM, receive_message);


    while (true) {
        if (uBit.serial.isReadable()) {
            // minicom -D /dev/ttyACM0
            ManagedString s = uBit.serial.read(32, ASYNC);
            uBit.display.clear();
            uBit.display.print(s);
            uBit.serial.send(s); // TO VIEW THE DATA RECEIVED
            sendOrder(s);
            uBit.sleep(3000);
            uBit.display.clear();
        }   

        // TEST ENVOIE 123
        if (uBit.buttonA.isPressed()) {
            sendIdRequest();
            uBit.serial.send("id-28");
        }

        // TEST ENVOIE 321
        if (uBit.buttonB.isPressed()) {
            sendOrder("321"); 
            uBit.display.print("321");
        }

        uBit.sleep(100); 
    }
}